import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class GamesList {
	private List footballGames;
	
	public GamesList() {
		footballGames = new LinkedList();
	}
	
	public void addFootballGame(String name, FootballRules rules) {
		FootballGame game = new FootballGame(name, rules);
		footballGames.add(game);
	}
	
	public FootballGame getFootballGame(String name) {
		for (Iterator i = footballGames.iterator(); i.hasNext(); ) {
			FootballGame footballGame = (FootballGame) i.next();
			if (footballGame.getName().equals(name)) {
				return footballGame;
			}
		}
		return null;
	}
	
	public List search(String ruleName, String rule) {
		List matchingFootballGames = new LinkedList();
		for (Iterator i = footballGames.iterator(); i.hasNext(); ) {
			FootballGame footballGame = (FootballGame) i.next();
			if (footballGame.getRules().matches(ruleName, rule))
				matchingFootballGames.add(footballGame);
		}
		return matchingFootballGames;
	}
}
