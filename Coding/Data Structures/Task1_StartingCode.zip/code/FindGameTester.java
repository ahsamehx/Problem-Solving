import java.util.Iterator;
import java.util.List;

public class FindGameTester {
	
	public static void main(String[] args) {
		GamesList gamesList = new GamesList();
		initializeGamesList(gamesList);
		
		String erinRule = "fieldSize";
		String whatErinLikes = "150";
		List matchingGames = gamesList.search(erinRule, whatErinLikes);
		if (!matchingGames.isEmpty()) {
			System.out.println("Erin, you might like these games:");
			for (Iterator i = matchingGames.iterator(); i.hasNext(); ) {
				FootballGame game = (FootballGame) i.next();
				FootballRules rules = game.getRules();
				System.out.println("  We have a game with match duration: " +
						rules.getMatchDuration() + " and field size: " + rules.getFieldSize() + " and referees count: " +
						rules.getRefereesCount() + " and team size: " +
						rules.getTeamSize() + "!\n  ----");
			}
		} else {
			System.out.println("Sorry, Erin, we have nothing for you.");
		}
	}
	
	private static void initializeGamesList(GamesList gamesList) {
		gamesList.addFootballGame("Small Game",
				new FootballRules("90", "5", "100", "2"));
		gamesList.addFootballGame("Short Game",
				new FootballRules("45", "11", "150", "4"));
		gamesList.addFootballGame("Standard Game",
				new FootballRules("90", "11", "150", "4"));
		gamesList.addFootballGame("Long Game",
				new FootballRules("120", "11", "150", "6"));
		gamesList.addFootballGame("Fast Game",
				new FootballRules("20", "5", "70", "1"));
		gamesList.addFootballGame("Street Game",
				new FootballRules("20", "4", "50", "0"));
	}
}
