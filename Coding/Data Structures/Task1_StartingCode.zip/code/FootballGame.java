public class FootballGame {
	
	private String name;
	FootballRules rules;
	
	public FootballGame(String name, FootballRules rules) {
		this.name = name;
		this.rules = rules;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public FootballRules getRules() {
		return rules;
	}
	
	public void setRules(FootballRules rules) {
		this.rules = rules;
	}
}
