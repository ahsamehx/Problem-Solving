public class FootballRules {
	private String matchDuration;
	private String teamSize;
	private String fieldSize;
	private String refereesCount;
	
	public FootballRules(String matchDuration, String teamSize, String fieldSize,
						 String refereesCount) {
		this.matchDuration = matchDuration;
		this.teamSize = teamSize;
		this.fieldSize = fieldSize;
		this.refereesCount = refereesCount;
	}
	
	public String getMatchDuration() {
		return matchDuration;
	}
	
	public void setMatchDuration(String matchDuration) {
		this.matchDuration = matchDuration;
	}
	
	public String getTeamSize() {
		return teamSize;
	}
	
	public void setTeamSize(String teamSize) {
		this.teamSize = teamSize;
	}
	
	public String getFieldSize() {
		return fieldSize;
	}
	
	public void setFieldSize(String fieldSize) {
		this.fieldSize = fieldSize;
	}
	
	public String getRefereesCount() {
		return refereesCount;
	}
	
	public void setRefereesCount(String refereesCount) {
		this.refereesCount = refereesCount;
	}
	
	
	
	public boolean matches(String ruleName, String rule) {
		
		switch (ruleName) {
			case "matchDuration":
				if (matchDuration.equals(rule))
					return true;
				return false;
			case "teamSize":
				if (teamSize.equals(rule))
					return true;
				return false;
			case "fieldSize":
				if (fieldSize.equals(rule))
					return true;
				return false;
			case "refereesCount":
				if (refereesCount.equals(rule))
					return true;
				return false;
			default:
				return false;
		}
	}
}
